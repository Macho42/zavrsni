import React from 'react'

function CetvrtiKorak() {
  return (
    <div>
    <h1>Čestitamo</h1>
    <p>Došli ste do kraja ove multistep forme</p>
  </div>  
  )
}

export default CetvrtiKorak